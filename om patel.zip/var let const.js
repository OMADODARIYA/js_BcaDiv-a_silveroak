var num=100;
var str="mozart";
var Boolenver="true";
  
document.write("<br/>",num);
document.write("<br/>",str);
document.write("<br/>",Boolenver);

document.write("<br/>",typeof(Boolenver));

var obj=new Object();
var obj={
    FirstName:"mozart",
    LastName:"ceramic",
}
document.write("<br/>"+typeof(obj));
document.write("<br/>"+obj.FirstName+"<br/>"+obj.LastName); 
var demo=function(){
    return "hey guess";
}
document.write("<br/>"+demo());
document.write("<br/>"+typeof(demo));

var car=["scorpio","fortuner","endevour"]
document.write("<br/>"+car[0]);
document.write("<br/>"+car[1]);
document.write("<br/>"+car[2]);

//const
 
const a=5;
const b=5;
let total=(a+b);
document.write("<br/>"+total)
