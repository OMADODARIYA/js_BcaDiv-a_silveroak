var a=["Silver oak"]
document.write(a instanceof Array);

document.write("<br/>");

//class instant of\
class Rectangle{
    constructor(height,width){
        this.height =height;
        this.width =width;
    }
}
var R=new Rectangle(20,30);
document.write(R instanceof Rectangle);
document.write("<br/>");
document.write(R.height+R.width);