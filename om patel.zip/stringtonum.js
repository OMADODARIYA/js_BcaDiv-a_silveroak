//The global method Number() can convert string to numbers.

document.write("<br/>"+Number("3.141516"));
document.write("<br/>"+Number(" 2 "));
document.write("<br/>"+Number(""));
document.write("<br/>"+Number("11 44"));

//The global method string()can convert number to string

let num=111;
let s=String(100 + 33);
document.write("<br/>"+String(num));
document.write("<br/>"+String(123));
document.write("<br/>"+String(s+100+33));
document.write("<br/>"+String("100"+"33")+String("100"+"33"));

//The toExponential()method return a string, with the number rounded and written

let numexp=3.14;
document.write("<br/>"+numexp.toExponential(1));
document.write("<br/>"+numexp.toExponential(2));
document.write("<br/>"+numexp.toExponential(4));
document.write("<br/>"+numexp.toExponential(6));

//The toFixed() return a string, with the number written a specified number 

let numfixed=3.14;
document.write("<br/>"+numfixed.toFixed());
document.write("<br/>"+numfixed.toFixed(2));
document.write("<br/>"+numfixed.toFixed(4));
document.write("<br/>"+numfixed.toFixed(6));

 //The toPrecision()method return a string, with a number written with a specified number

let numPrec=3.14;
document.write("<br/>"+numPrec.toPrecision());
document.write("<br/>"+numPrec.toPrecision(2));
document.write("<br/>"+numPrec.toPrecision(4));
document.write("<br/>"+numPrec.toPrecision(6));

 //Number,paraselnt,parseFloat.

 document.write("<br/>"+Number(true));
 document.write("<br/>"+Number(false));
 document.write("<br/>"+Number("11"));
 document.write("<br/>"+Number(" 11"));
 document.write("<br/>"+Number("11 "));
 document.write("<br/>"+Number(" 11 "));
 document.write("<br/>"+Number("11.33"));
 document.write("<br/>AAA"+Number("11,33"));
 document.write("<br/>"+Number("11 33"));
 document.write("<br/>"+Number("ABC"));
 document.write("<br/>"+Number(new Date("2004-12-12")));

 document.write("<br/>MIN_VALUE,MAX_VALUE,POSITIVE_INFINITY,NEGATIVE_INFINITY");

 // date year time month hours minute second milisecond

document.write("<br/>"+new Date());
document.write("<br/>"+new Date("2004-4-11"));
document.write("<br/>"+new Date("april 11,2004 11:12:00"));
   
var d = new Date();

document.write("<br/>"+d.toString());
document.write("<br/>"+d.toUTCString());
document.write("<br/>"+d.toDateString());
document.write("<br/>"+d.toISOSstring());

document.write("<br/>"+d.togetTime());
document.write("<br/>"+d.getDate());
document.write("<br/>"+d.getDay());
document.write("<br/>"+d.getFullYear());
document.write("<br/>"+d.getHours());
document.write("<br/>"+d.getMonth());

document.write("<br/>"+d.getDay()+"/"+d.getMonth()+"/"+d.getFullYear()+"/"+d.getDate()+"/"+d.getMilliseconds())
