let n1=30,n2=20;
var sum=n1+n2,mul=n1*n2,sub=n1-n2,div=n1/n2,mod=n1%n2;
var Exponentiation=5**2;
document.write("<br/>sum:",sum+"<br/>mul:",mul+"<br/>sub:",sub+"<br/>div:",div+"<br/>mod:",mod)